package com.example.Crud_operation1.repository;

import com.example.Crud_operation1.model.UserModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<UserModel, Long> {
}
